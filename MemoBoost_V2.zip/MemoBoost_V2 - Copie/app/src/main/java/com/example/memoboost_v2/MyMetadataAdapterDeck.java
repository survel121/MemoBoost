package com.example.memoboost_v2;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyMetadataAdapterDeck extends RecyclerView.Adapter<MyMetadataAdapterDeck.ViewHolder>{

    Context myContext;
    
    public MyMetadataAdapterDataList_Decks[] listDecks;
    private Intent intent;


    //public MyMetadataAdapterDataList_Categories[] listCategories;

    /*public MyMetadataAdapter(Context myContext, MyMetadataAdapterDataList_Categories[] listCategories, MyMetadataAdapterDataList_Decks[] listDecks, Intent intent) {
        this.myContext = myContext;
        this.listCategories = listCategories;
        this.listDecks = listDecks;
        this.intent = intent;
    } */
    public MyMetadataAdapterDeck(Context myContext, MyMetadataAdapterDataList_Decks[] listDecks, Intent intent) {
        this.myContext = myContext;
        //this.listCategories = listCategories;
        this.listDecks = listDecks;
        this.intent = intent;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(myContext).inflate(R.layout.metadata_single_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        //holder.myDbElement.setText(listCategories[position].getName());
        //holder.myDbElement.setText("I'm ADDING TEXT HERE");
        holder.myDbElement.setText(listDecks[position].getName());
        Log.d("NUMB DECKS", String.valueOf(position));
    }

    @Override
    public int getItemCount() {
        return listDecks.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView myDbElement;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            myDbElement = (TextView) itemView.findViewById(R.id.MetadataText);
        }
    }
}
