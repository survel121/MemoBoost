package com.example.memoboost_v2;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyMetadataAdapterCategory extends RecyclerView.Adapter<MyMetadataAdapterCategory.ViewHolder> {

    Context myContext;

    public MyMetadataAdapterDataList_Categories[] listCategories;

    private Intent intent;

    public MyMetadataAdapterCategory(Context myContext, MyMetadataAdapterDataList_Categories[] listCategories, Intent intent) {
        this.myContext = myContext;
        this.listCategories = listCategories;
        this.intent = intent;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(myContext).inflate(R.layout.metadata_single_item, parent, false);
        return new MyMetadataAdapterCategory.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.myDbElement.setText(listCategories[position].getName());
        Log.d("NUMB DECKS", String.valueOf(position));
    }

    @Override
    public int getItemCount() {
        return listCategories.length;
    }



    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView myDbElement;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            myDbElement = (TextView) itemView.findViewById(R.id.MetadataText);
        }
    }
}
