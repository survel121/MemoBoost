package com.example.memoboost_v2;

public class MyMetadataAdapterDataList_Decks {
    // Class to Display the Decks name in the RecyclerView that allows creation o Decks Names
    private String name;
    private int ID_Deck;

    public MyMetadataAdapterDataList_Decks(String name, int idDeck){
        this.name = name;
        this.ID_Deck = idDeck;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getID_Deck() {
        return ID_Deck;
    }

    public void setID_Deck(int ID_Deck) {
        this.ID_Deck = ID_Deck;
    }
}
