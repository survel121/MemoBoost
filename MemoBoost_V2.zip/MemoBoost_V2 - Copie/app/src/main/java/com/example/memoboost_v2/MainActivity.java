package com.example.memoboost_v2;


import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    RecyclerView myRecyclerView;
    DatabaseManager_Cards myManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        planifierNotification();
    }

    protected void onResume() {
        super.onResume();

        myManager = new DatabaseManager_Cards(this);

        int iCardAmount = myManager.read_Data_Cards_Amount();
        Log.d("INFO TEMP", "Lancement de l'appli RESUME");
        int[] iCardIDs = myManager.read_Data_IDs(iCardAmount);

        Log.d("INFO TEMP", "CardAmount = " + iCardAmount );


        // Supprimer la barre de titre
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }

        Button buttonCreateCard = findViewById(R.id.buttonAddCard);
        buttonCreateCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openCardMenu();
            }
        });

        CardDatabaseDataList[] listData = new CardDatabaseDataList[iCardAmount];

        for (int i = 0; i < iCardAmount; i++) {
            listData[i] = new CardDatabaseDataList(myManager.read_Data_Question(iCardIDs[i]), R.drawable.ic_launcher_background, iCardIDs[i]);
        }
        myRecyclerView = (RecyclerView) findViewById(R.id.recyclerViewCardSelection);

        MyAdapter adapter = new MyAdapter(this, listData, new Intent(this, CreateCardScreen.class));
        myRecyclerView.setHasFixedSize(true);
        myRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        myRecyclerView.setAdapter(adapter);
        Log.d("Number of Cards!", String.valueOf(iCardIDs.length));

        Button buttonCreateMetadata = (Button) findViewById(R.id.btnAddMetaData);
        buttonCreateMetadata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openMetadataMenu();
            }
        });

        Button myLearningButton = (Button) findViewById(R.id.btnLearnMode);
        myLearningButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openLearningMenu();
            }
        });
    }

    public void openCardMenu() {
        Intent intent = new Intent(this, CreateCardScreen.class);
        intent.putExtra("Card_Type", "Create");
        startActivity(intent);
    }

    public void openMetadataMenu() {
        Intent intent = new Intent(this, CreateMetadata.class);
        startActivity(intent);
    }

    public void openLearningMenu(){
        Intent intent = new Intent(this, StudyCardScreen.class);
        startActivity(intent);
    }

    public void planifierNotification(){
        Log.d("INFO TEMP", "PARTIE 1");

        // Récupérer l'instance de l'AlarmManager
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

        Log.d("INFO TEMP", "PARTIE 2");

        // Créer un Intent pour déclencher le BroadcastReceiver
        Intent intent = new Intent(this, NotificationReceiver.class);
        Log.d("INFO TEMP", "PARTIE 2 BIS");
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, intent, flags);

        Log.d("INFO TEMP", "PARTIE 3");

        // Définir l'heure de déclenchement (par exemple, 9h du matin)
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        calendar.set(Calendar.HOUR_OF_DAY, 11);
        calendar.set(Calendar.MINUTE, 35);
        calendar.set(Calendar.SECOND, 0);

        Log.d("INFO TEMP", "PARTIE 4");

        // Programmer l'alarme pour qu'elle se répète tous les jours à la même heure
        if (alarmManager != null) {
            alarmManager.setInexactRepeating(
                    AlarmManager.RTC_WAKEUP,
                    calendar.getTimeInMillis(),
                    AlarmManager.INTERVAL_DAY,
                    pendingIntent
            );
        }
        Log.d("INFO TEMP", "PARTIE 5");
    }
}