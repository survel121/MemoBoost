package com.example.memoboost_v2;

public class MyMetadataAdapterDataList_Categories {

    // Class to Display the Categories name in the RecyclerView that allows creation o Categories names
    private String name;
    private int ID_Cat;

    public MyMetadataAdapterDataList_Categories(String name, int idCat){
        this.name = name;
        this.ID_Cat = idCat;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int ID_Cat() {
        return ID_Cat;
    }

    public void setID_Cat(int ID_Cat) {
        this.ID_Cat = ID_Cat;
    }

}
