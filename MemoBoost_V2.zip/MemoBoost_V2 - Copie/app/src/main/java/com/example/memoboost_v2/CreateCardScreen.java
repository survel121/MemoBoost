package com.example.memoboost_v2;


import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.activity.result.contract.ActivityResultContracts;

import android.Manifest;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.viewbinding.ViewBinding;

public class CreateCardScreen extends AppCompatActivity {

    EditText editQuestionText;
    EditText editAnswerText;

    DatabaseManager_Cards myCardsManager;

    private int myIntegerIDCard = 0;    // We will have to check if there is a card selected!
    RelativeLayout myBackCard;
    RelativeLayout myCard;

    ImageView myQuestionImageView;
    private String URI_Question_Image;
    Button myQuestionImageBtn;
    private static final int PICK_IMAGE_REQUEST = 1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_card_screen2);

        myCardsManager = new DatabaseManager_Cards(this);


        /*if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
        } */


        // Delete the Title Bar from the top of the screen
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }

        Button buttonSaveCard = findViewById(R.id.buttonSaveCard);

        // Declaring the Edit Text / Text Area
        editQuestionText = (EditText) findViewById(R.id.editQuestion);
        editAnswerText = (EditText) findViewById(R.id.editTextAnswer);

        buttonSaveCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //SaveCard();
                PopupMenu popupMenu = new PopupMenu(CreateCardScreen.this, buttonSaveCard);
                popupMenu.getMenuInflater().inflate(R.menu.popup_menu_save_card_button, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        Toast.makeText(CreateCardScreen.this, "You Clicked " + menuItem.getTitle(), Toast.LENGTH_SHORT).show();
                        String strTitle = (String) menuItem.getTitle();
                        switch (strTitle) {
                            case "Update Card":
                                Toast.makeText(CreateCardScreen.this, "UPDATE", Toast.LENGTH_SHORT).show();
                                UpdateCard();
                                break;

                            case "Save Card":
                                Toast.makeText(CreateCardScreen.this, "SAVE CARD", Toast.LENGTH_SHORT).show();
                                SaveCard();
                                break;
                            default:
                                Toast.makeText(CreateCardScreen.this, "BUGGED", Toast.LENGTH_SHORT).show();
                                break;
                        }

                        return true;
                    }
                });
                popupMenu.show();
            }
        });


        LayoutInflater myInflater = LayoutInflater.from(this);
        View footerView = myInflater.inflate(R.layout.data_menu_card_screen, null, false);
        LinearLayout myLinearLayout = (LinearLayout) findViewById(R.id.LinearLayoutDisplayDataMenu);
        myLinearLayout.addView(footerView);





        // Receiving the EXTRA DATA put from another class.
        if (getIntent() != null && getIntent().hasExtra("ID_Card")) {
            int myInteger = getIntent().getIntExtra("ID_Card", 0);
            Log.d("THE INTEGER RECEIVED", String.valueOf(myInteger));
            DisplayQuestion(myInteger);
            myIntegerIDCard = myInteger;

        } else{
            myIntegerIDCard = myCardsManager.read_current_ID(editQuestionText.getText().toString());
        }

        Button buttonShowFirstQuestion = findViewById(R.id.ShowTheFirst);
        buttonShowFirstQuestion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RotateCard();
            }
        });


        TextView myIntentTitle = findViewById(R.id.textViewTitle);
        if (getIntent() != null && getIntent().hasExtra("Card_Type")) {
            switch (getIntent().getStringExtra("Card_Type")) {
                case "Update":
                    myIntentTitle.setText("MAJ de la carte");
                    break;
                case "Create":
                    myIntentTitle.setText("Créer une nouvelle Carte");
                    break;
                default:
                    break;
            }
        }

        Button returnMenu = (Button) findViewById(R.id.btnExitScreen);
        returnMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        myQuestionImageBtn = findViewById(R.id.button2);
        myQuestionImageView = findViewById(R.id.imageViewCardQuestion);
        myQuestionImageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Nothing happens when clicking on the image button for now...
            }
        });

        myBackCard = (RelativeLayout) findViewById(R.id.relativeLayoutBackCard);
        myCard = (RelativeLayout) findViewById(R.id.relativeLayout);
        myBackCard.setAlpha(0f);
        myBackCard.setVisibility(View.GONE);

        Log.d("TEST", "message");

        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) TextView txtDeck = (TextView) findViewById(R.id.textViewDeckName);
        txtDeck.setText("My Deck is supposed to be here!");

        if (getIntent() != null && getIntent().hasExtra("ID_Card")) {
            // Vérification de la présence d'un Deck pour la carte
            String strCardDeckName = myCardsManager.retrieve_Deck_Name(myIntegerIDCard);
            if (strCardDeckName != null) {
                txtDeck.setText(strCardDeckName);
            } else {
                Log.d("DECK_NAME_CARD", strCardDeckName);
            }
        }

        // On ajoute la selection d'un élément Deck sur le CreateCardScreen lorsque l'on veut ajouter un Deck à une carte
        txtDeck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu myPopUpMenu = new PopupMenu(CreateCardScreen.this, txtDeck);
                String[] dynamicMenuItems = {"Decks", "Item 1", "Item 2", "Item 3", "Item 4", "Item 5", "Item 6", "Item 7", "Item 8", "Item 9", "Item 10", "Item 11", "Item 12", "Item 13", "Item 14"};

                // Tableau qui permet de récupérer la totalité des noms de Decks à afficher dans le PopupMenu
                String[] newList = myCardsManager.read_All_Decks_Name();
                for(int i = 0; i < newList.length; i++){
                    Log.d("ELEMENT X ", newList[i]);
                }

                dynamicMenuItems = newList;

                for (int i = 0; i < dynamicMenuItems.length; i++) {
                    myPopUpMenu.getMenu().add(0, i, i, dynamicMenuItems[i]);
                }

                String[] finalDynamicMenuItems = dynamicMenuItems;
                myPopUpMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener(){
                    @Override
                    public boolean onMenuItemClick(MenuItem item){
                        Toast.makeText(CreateCardScreen.this, finalDynamicMenuItems[item.getItemId()] + " Sélectionné", Toast.LENGTH_SHORT).show();
                        txtDeck.setText(finalDynamicMenuItems[item.getItemId()]);
                        myCardsManager.save_deck_on_card(myIntegerIDCard, (String) txtDeck.getText());
                        return true;
                    }
                });

                // Pour afficher le menu :
                myPopUpMenu.show();

            }
        });

        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) TextView txtTags = (TextView) findViewById(R.id.textViewCardTags);
        txtTags.setText("Tags are displayed here");

        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) TextView txtFavorite = (TextView) findViewById(R.id.textViewMarkAsFavorite);
        txtFavorite.setText("Marquer comme favoris");


    }

    public void Save_URI_into_DB(){
        myCardsManager.insert_URI_Question(this.URI_Question_Image, myIntegerIDCard);
    }


    public void SaveCard() {

        // Saving all the data of the card here

        Log.d("Save Card", "Saving card into the Database");
        String tempText = editQuestionText.getText().toString();
        if (tempText.equals("Write your Question here") || tempText.isEmpty()) {
            Toast.makeText(this, "New Value Please!", Toast.LENGTH_SHORT).show();
        } else {
            // If there is a question referenced here!
            Log.d("Another Question", tempText);
            Toast.makeText(this, "Value = " + tempText, Toast.LENGTH_SHORT).show();
            // We update the Database/saving data
            if (!myCardsManager.is_already_present(tempText)){
                myCardsManager.insert_Data(tempText);

                if (!editAnswerText.getText().toString().isEmpty()){    // If editAnswerText isn't Empty
                    myCardsManager.update_Answer( tempText,editAnswerText.getText().toString());
                } else{}
            } else {
                Log.d("State Card", "This card already Exists");
                Toast.makeText(this, "This question is already stored!", Toast.LENGTH_SHORT).show();
            }

        }
    }

    public void UpdateCard(){
        String strNewQuestion = editQuestionText.getText().toString();
        if (!strNewQuestion.isEmpty()){
            if (!myCardsManager.is_already_present_via_update(strNewQuestion, myIntegerIDCard)){
                Log.d("Already Here", "New question entered");
                myCardsManager.update_Question(myIntegerIDCard, strNewQuestion);
            } else{
                Toast.makeText(this, "This question is already stored!", Toast.LENGTH_SHORT).show();
                Toast.makeText(this, "But the Answer Has been updated", Toast.LENGTH_SHORT).show();
            }
        } else{}

        String strNewAnswer = editAnswerText.getText().toString();
        if (!strNewAnswer.isEmpty()){
            myCardsManager.update_Answer(editQuestionText.getText().toString(), strNewAnswer);
        }else{}
        if (myQuestionImageView.getDrawable() != null) {
            myCardsManager.insert_URI_Question(this.URI_Question_Image, myIntegerIDCard);
            //Toast.makeText(this, "ADDING THE IMAGE !!!", Toast.LENGTH_SHORT).show();
        } else{}
    }

    public void DisplayQuestion(int i) {
        // Writing the question in the EditText Area!
        String myResult = myCardsManager.read_Data_Question(i);
        editQuestionText.setText(myResult);

        // All the SAVED DATA will be displayed there :

            // IF answer isn't Empty Then write the answer on the card

        String myResult2 = myCardsManager.read_Answer(i);
        editAnswerText.setText(myResult2);

            //Not necessary!!!
        //Toast.makeText(this, "Identifiant : "+ i, Toast.LENGTH_SHORT).show();
    }

    public void RotateCard() {
        if (myBackCard.getAlpha() == 0) {
            ObjectAnimator animator = ObjectAnimator.ofFloat(myCard, "rotationX", 0, 90);
            animator.setDuration(500);
            animator.setInterpolator(AnimationUtils.loadInterpolator(this, android.R.anim.accelerate_decelerate_interpolator));
            animator.start();
            animator.addListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    super.onAnimationEnd(animation);
                    myCard.setAlpha(0f);
                    myBackCard.setAlpha(1f);
                    myBackCard.setVisibility(View.VISIBLE);
                    ObjectAnimator animator2 = ObjectAnimator.ofFloat(myBackCard, "rotationX", -90, 0);
                    animator2.setDuration(500);
                    animator2.setInterpolator(AnimationUtils.loadInterpolator(CreateCardScreen.this, android.R.anim.accelerate_decelerate_interpolator));
                    animator2.start();
                }
            });
        } else {
            ObjectAnimator animator2 = ObjectAnimator.ofFloat(myBackCard, "rotationX", 0, 90);
            animator2.setDuration(500);
            animator2.setInterpolator(AnimationUtils.loadInterpolator(CreateCardScreen.this, android.R.anim.accelerate_decelerate_interpolator));
            animator2.start();
            animator2.addListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    super.onAnimationEnd(animation);
                    myBackCard.setAlpha(0f);
                    myCard.setAlpha(1f);
                    myBackCard.setVisibility(View.GONE);
                    ObjectAnimator animator = ObjectAnimator.ofFloat(myCard, "rotationX", -90, 0);
                    animator.setDuration(500);
                    animator.setInterpolator(AnimationUtils.loadInterpolator(CreateCardScreen.this, android.R.anim.accelerate_decelerate_interpolator));
                    animator.start();
                }
            });
        }
    }


    // This Method isn't used YET -- We don't need the Gallery right Now (10/11/2024)
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission accordée
            } else {
                // Permission refusée
                Toast.makeText(this, "Permission d'accès à la galerie refusée", Toast.LENGTH_SHORT).show();
            }
        }
    }
}