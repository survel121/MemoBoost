package com.example.memoboost_v2;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CreateMetadata extends AppCompatActivity {

    DatabaseManager_Cards myManager;

    Button btnSaveData;
    EditText editText_DeckName;
    EditText editText_CategoryName;

    RecyclerView myRecyclerView;
    RecyclerView myRecyclerView2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_metadata);

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }

        btnSaveData = (Button) findViewById(R.id.btnSaveMetaData);
        editText_DeckName = (EditText) findViewById(R.id.editTextAddDeck);
        editText_CategoryName = (EditText) findViewById(R.id.editTextAddCategory);

        btnSaveData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveData();
            }
        });

        myManager = new DatabaseManager_Cards(this);



        myRecyclerView = (RecyclerView) findViewById(R.id.recyclerViewDeck);

        int iDeckAmount = myManager.read_Data_Decks_Amount();
        Log.d("NUmb DECKS", "Numero = " + String.valueOf(iDeckAmount));

        int[] iDeckIDs = myManager.read_Deck_IDs(iDeckAmount);
        MyMetadataAdapterDataList_Decks[] listData = new MyMetadataAdapterDataList_Decks[iDeckAmount-1];
        for (int i=0; i < iDeckAmount-1; i++){
            int i2 = i;
            listData[i] = new MyMetadataAdapterDataList_Decks(myManager.read_Data_Deck_Name(i2+1), iDeckIDs[i2+1]);
        }
        MyMetadataAdapterDeck adapter = new MyMetadataAdapterDeck(this, listData, new Intent(this, CreateMetadata.class));
        myRecyclerView.setHasFixedSize(true);
        myRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        myRecyclerView.setAdapter(adapter);



        myRecyclerView2 = (RecyclerView) findViewById(R.id.recyclerViewCat);

        int iCatAmount = myManager.read_Data_Categories_Amount();
        int[] iCatIDs = myManager.read_Category_IDs(iCatAmount);
        MyMetadataAdapterDataList_Categories[] listData2 = new MyMetadataAdapterDataList_Categories[iCatAmount-1];

        for (int i=0; i < iCatAmount-1; i++){
            int i2 = i;
            listData2[i] = new MyMetadataAdapterDataList_Categories(myManager.read_Data_Category_Name(i2+1), iCatIDs[i2+1]);
        }
        MyMetadataAdapterCategory adapterCat = new MyMetadataAdapterCategory(this, listData2, new Intent(this, CreateMetadata.class));
        myRecyclerView2.setHasFixedSize(true);
        myRecyclerView2.setLayoutManager(new LinearLayoutManager(this));
        myRecyclerView2.setAdapter(adapterCat);
        Log.d("NUmb CATS", "Numero = " + String.valueOf(iCatAmount));



    }


    public void saveData(){
        String strDeckName = editText_DeckName.getText().toString();
        String strCatName = editText_CategoryName.getText().toString();

        if (strDeckName.isEmpty()){

        } else{
            //Toast.makeText(this, "editText DECK NAME isn't empty", Toast.LENGTH_SHORT).show();
            myManager.insert_Data_Decks_Table(strDeckName);
        }

        if (strCatName.isEmpty()){

        }else{
            //Toast.makeText(this, "editText CAT NAME isn't empty", Toast.LENGTH_SHORT).show();
            myManager.insert_Data_Categories_Table(strCatName);
        }


    }

    public void DisplayDeckName(int i) {
        // Writing the question in the EditText Area!
        String myResult = myManager.read_Data_Question(i);
        editText_DeckName.setText(myResult);
    }
}