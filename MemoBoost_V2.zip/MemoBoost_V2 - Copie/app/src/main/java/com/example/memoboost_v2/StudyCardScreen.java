package com.example.memoboost_v2;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

//import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class StudyCardScreen extends AppCompatActivity {

    TextView txtViewQuestionText;
    TextView txtViewAnswerText;
    DatabaseManager_Cards myCardsManager;

    private int myIntegerIDCard = 0;

    RelativeLayout myBackCard;
    RelativeLayout myCard;
    int iCurrentCardID = 1; // Valeur initiale dans la BDD pour lire La toute première carte


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_study_card_screen);


        myCardsManager = new DatabaseManager_Cards(this);

        myBackCard = findViewById(R.id.relativeLayoutBackCard);
        myCard = findViewById(R.id.relativeLayout);


        // Delete the Title Bar from the top of the screen
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }

        Button rotateCardButton = (Button) findViewById(R.id.ShowTheFirst);
        rotateCardButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RotateCard();
            }
        });


            // Retrieving the Data for both Question and the answer from the Current Card!
        txtViewQuestionText = findViewById(R.id.txtViewTextQuestion);
        txtViewAnswerText = findViewById(R.id.txtViewTextAnswer);


            // Mise en place de la lecture de la carte Actuelle et de la Suivante
        Button nextCard = (Button) findViewById(R.id.buttonNextCard);
        int nbCardsStored = myCardsManager.read_Data_Cards_Amount();
        Log.d("nbCardsStored", "nbCard = " + nbCardsStored);

        if (nbCardsStored > 0){
            DisplayQuestion(iCurrentCardID);
            Log.d("nbCardStored", "Il y a plus de 0 cartes dans la base de données");
        }else {
            Log.d("nbCardsStored", "AUCUNE carte disponible à la lecture...");
            nextCard.setEnabled(false);
            txtViewQuestionText.setText("Tu es arrivé au bout des révisions, Bravo!");
            txtViewAnswerText.setText("Tu es arrivé au bout des révisions, Bravo!");
        }
        nextCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // FOnction a exécuter à chaque Appui sur le Bouton Next!!!
                if (iCurrentCardID < nbCardsStored){
                    iCurrentCardID++;
                    DisplayQuestion(iCurrentCardID);
                        // Mettre en place un système de filtre ici
                } else {
                    Log.d("nbCardsStored", "Plus de carte disponible à la révision...");
                    nextCard.setEnabled(false);
                    txtViewQuestionText.setText("Tu es arrivé au bout des révisions, Bravo!");
                    txtViewAnswerText.setText("Tu es arrivé au bout des révisions, Bravo!");
                }
            }
        });

            // Fin mise en place de la Lecture!

            // Button To leave the current Activity
        Button returnMenu = (Button) findViewById(R.id.btnExitScreen);
        returnMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }




    public void DisplayQuestion(int i) {

        String myResult = myCardsManager.read_Data_Question(i);
        //String myResult = "QUESTION";
        txtViewQuestionText.setText(myResult);

        // All the SAVED DATA will be displayed there :

        String myResult2 = myCardsManager.read_Answer(i);
        //String myResult2 = "ANSWER";
        txtViewAnswerText.setText(myResult2);

    }


    public void RotateCard() {
        if (myBackCard.getAlpha() == 0) {
            ObjectAnimator animator = ObjectAnimator.ofFloat(myCard, "rotationX", 0, 90);
            animator.setDuration(500);
            animator.setInterpolator(AnimationUtils.loadInterpolator(this, android.R.anim.accelerate_decelerate_interpolator));
            animator.start();
            animator.addListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    super.onAnimationEnd(animation);
                    myCard.setAlpha(0f);
                    myBackCard.setAlpha(1f);
                    myBackCard.setVisibility(View.VISIBLE);
                    ObjectAnimator animator2 = ObjectAnimator.ofFloat(myBackCard, "rotationX", -90, 0);
                    animator2.setDuration(500);
                    animator2.setInterpolator(AnimationUtils.loadInterpolator(StudyCardScreen.this, android.R.anim.accelerate_decelerate_interpolator));
                    animator2.start();
                }
            });
        } else {
            ObjectAnimator animator2 = ObjectAnimator.ofFloat(myBackCard, "rotationX", 0, 90);
            animator2.setDuration(500);
            animator2.setInterpolator(AnimationUtils.loadInterpolator(StudyCardScreen.this, android.R.anim.accelerate_decelerate_interpolator));
            animator2.start();
            animator2.addListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    super.onAnimationEnd(animation);
                    myBackCard.setAlpha(0f);
                    myCard.setAlpha(1f);
                    myBackCard.setVisibility(View.GONE);
                    ObjectAnimator animator = ObjectAnimator.ofFloat(myCard, "rotationX", -90, 0);
                    animator.setDuration(500);
                    animator.setInterpolator(AnimationUtils.loadInterpolator(StudyCardScreen.this, android.R.anim.accelerate_decelerate_interpolator));
                    animator.start();
                }
            });
        }
    }
}