package com.example.memoboost_v2;

public class CardDatabaseDataList {
    // This class allow me to display both a Name and an image into the recyclerView
    private String name;
    private int imgId;
    private int iIDCard;

    public CardDatabaseDataList(String name, int imgId, int ID_Card) {
        this.name = name;
        this.imgId = imgId;
        this.iIDCard = ID_Card;
    }

        // Returning the global private Name (= the question of the card)
    public String getName() {
        return name;
    }

        // Changing the global private Name (= the question of the card)
    public void setName(String name) {
        this.name = name;
    }

        // Returning the img of the card (an image is shown on the left side of the title
    public int getImgId() {
        return imgId;
    }

    public void setImgId(int imgId) {
        this.imgId = imgId;
    }

        // Returning the ID of the card (allows us to select it and show the right card)
    public int getiIDCard() {
        return iIDCard;
    }

    public void setiIDCard(int iIDCard) {
        this.iIDCard = iIDCard;
    }
}
