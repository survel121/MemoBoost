package com.example.memoboost_v2;


import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import android.database.Cursor;
import android.util.Log;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Objects;


public class DatabaseManager_Cards extends SQLiteOpenHelper {

    private static final String name = "Cards.db";
    private static final int version = 5;

    public DatabaseManager_Cards(Context context) {
        super(context, name, null, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        // We want to create a first version of the Table with : The NAME of the Table "Cards", the "id" of the cards, the "question" from the card and it's "date" of creation
        //String SQL = "CREATE TABLE Cards (id_card integer PRIMARY KEY autoincrement, text_question TEXT not null, date_creation TEXT not null)";
        create_Database(sqLiteDatabase);
        //sqLiteDatabase.execSQL(SQL);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        delete_Database();
        create_Database(sqLiteDatabase);
    }


    private void create_Database(SQLiteDatabase myDatabase){
        String SQL = "CREATE TABLE IF NOT EXISTS Cards (id_card integer PRIMARY KEY autoincrement, " +
                "text_question TEXT not null, " +
                "date_creation TEXT not null, " +
                "image_question TEXT, " +
                "text_answer TEXT, " +
                "image_answer TEXT, " +
                "meta_category TEXT, " +
                "meta_deck TEXT," +
                "isFavorite INTEGER)";  //Boolean isn't recognised in SQL
        // BUT : if 0 => False ; if 1 => TRUE;
        myDatabase.execSQL(SQL);

        String SQL_Decks = "CREATE TABLE IF NOT EXISTS Decks (" +
                "id_deck integer PRIMARY KEY autoincrement," +
                "deck_name TEXT not null)";
        myDatabase.execSQL(SQL_Decks);

        String SQL_Categories = "CREATE TABLE IF NOT EXISTS Categories (" +
                "id_cat integer PRIMARY KEY autoincrement," +
                "cat_name TEXT not null)";
        myDatabase.execSQL(SQL_Categories);
    }

     public void delete_Database(){
        String SQL_delete = "DROP TABLE IF EXISTS Cards";
        this.getWritableDatabase().execSQL(SQL_delete);
        SQL_delete = "DROP TABLE IF EXISTS Decks";
        this.getWritableDatabase().execSQL(SQL_delete);
        SQL_delete = "DROP TABLE IF EXISTS Categories";
        this.getWritableDatabase().execSQL(SQL_delete);
    }


    public void insert_Data(String strData){
        SQLiteDatabase currentDB = this.getWritableDatabase();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        String currentDate = dateFormat.format(new Date());
        ContentValues values = new ContentValues();
        values.put("text_question", strData);
        values.put("date_creation",currentDate);

        currentDB.insert("Cards", null, values);
    }

    public int read_current_ID(String strQuestion){
        String SQL = "SELECT id_card FROM Cards WHERE text_question = '" + strQuestion + "'";
        Cursor cursor = this.getReadableDatabase().rawQuery(SQL, null);
        cursor.moveToFirst();
        if(cursor != null && cursor.getCount() > 0){
            int currentID = cursor.getInt(0);
            return currentID;
        }
        else {
            return -1;
        }
    }

    public String read_Data(){
        String SQL = "SELECT * FROM Cards WHERE id_card = 1";       // Select ONLY the first ID at the moment!!! Have to change it soon...
        Cursor cursor = this.getReadableDatabase().rawQuery(SQL, null);
        cursor.moveToFirst();

        if(cursor != null && cursor.getCount() > 0){
            String str = cursor.getString(1); // The Question
            String str2 = cursor.getString(2); // the Date

            return "The question is : " + str + " last Updated the " + str2;
        }
        else {
            return "L'ID est probablement mauvais!";
        }
    }

    public String read_Data_Question(int currentID){
        // Reading only the Question from a specific ID
        String SQL = "SELECT * FROM Cards WHERE id_card = " + currentID;
        Cursor cursor = this.getReadableDatabase().rawQuery(SQL, null);
        cursor.moveToFirst();

        if(cursor != null && cursor.getCount() > 0){
            String str = cursor.getString(1); // The Question
            return str ;
        }
        else {
            return null;
        }

    }

    public int read_Data_Cards_Amount(){
        //Reading the amount of elements in the Table Cards
        String SQL = "SELECT * FROM Cards";
        Cursor cursor = this.getReadableDatabase().rawQuery(SQL, null);
        cursor.moveToFirst();
        int iNumberOfCards = 0;
        if(cursor != null && cursor.getCount() > 0){
            iNumberOfCards = cursor.getCount();
        }

        return iNumberOfCards;
    }


    public int[] read_Data_IDs(int iAmount){
        int[] iValues = new int[iAmount];
        String SQL = "SELECT * FROM Cards WHERE id_card != 0";
        Cursor cursor = this.getReadableDatabase().rawQuery(SQL, null);
        cursor.moveToFirst();
        if (cursor != null){
            for (int i=0; i<iAmount;i++){
                iValues[i] = cursor.getInt(0);
                cursor.moveToNext();
            }
        } else{
            iValues[0] = 0;
        }

        return iValues;
    }

    public void update_Question(int iQuestion, String strData){
        /*String SQL = "UPDATE Cards SET text_question = '" + strData + "'WHERE id_card =" + iQuestion;
        this.getWritableDatabase().execSQL(SQL); */

        SQLiteDatabase currentDB = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("text_question", strData);
        String selection = "id_card = ?";
        String[] selectionArgs = { String.valueOf(iQuestion) };

        currentDB.update("Cards", values, selection, selectionArgs);
    }

    public void update_Answer(String strQuestion, String strData){
        /*String SQL = "UPDATE Cards SET text_answer = '" + strData + "' WHERE text_question = '"+ strQuestion + "'";
        this.getWritableDatabase().execSQL(SQL); */

        SQLiteDatabase currentDB = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("text_answer", strData);
        String selection = "text_question = ?";
        String[] selectionArgs = { strQuestion };

        currentDB.update("Cards", values, selection, selectionArgs);
    }

    public String read_Answer(int iQuestion){
        String SQL = "SELECT text_answer FROM Cards WHERE id_card = " + iQuestion;
        Cursor cursor = this.getReadableDatabase().rawQuery(SQL, null);
        cursor.moveToFirst();
        String strResult = cursor.getString(0);
        if (strResult != null ){
            Log.d("RESULT ANSWER BDD", strResult);
            return strResult;
        }
        else {
            Log.d("No answer YET", "NO ANSWER MA GUEULE");
            return "No answer YET";
        }
    }

    public void insert_URI_Question(String strLink, int iQuestion){
        if (iQuestion >0){
            String SQL = "UPDATE Cards SET image_question= '"+ strLink + "' WHERE id_card = " + iQuestion;
            this.getWritableDatabase().execSQL(SQL);
            Log.d("UPDATE CARD", "UPDATING CARD NUMBER " + iQuestion);
        } else { Log.d("UPDATE CARD", "Card not created YET"); }
    }


    public boolean is_already_present( String myQuestion){
        boolean isPresent = false;
        //myQuestion = "Question 1";
        /*String SQL = "SELECT * FROM Cards";
        Cursor cursor = this.getReadableDatabase().rawQuery(SQL, null); */

        SQLiteDatabase currentDB = this.getWritableDatabase();
        String[] columns = {"text_question"};
        Cursor cursor = currentDB.query("Cards", columns, null ,null, null, null, null);
        cursor.moveToFirst();
        if(cursor != null && cursor.getCount() > 0){
           do{
               if (Objects.equals(cursor.getString(cursor.getColumnIndex("text_question")), myQuestion)){
                   isPresent = true;
               }
           }while (cursor.moveToNext());    // Reading the all TABLE
        }

        return isPresent;
    }

    public boolean is_already_present_via_update(String myQuestion, int currentId){
            // If someone tries to Update a card with the Same Question as another
        boolean isPresent = false;
        /*String SQL = "SELECT * FROM Cards";
        Cursor cursor = this.getReadableDatabase().rawQuery(SQL, null); */

        SQLiteDatabase currentDB = this.getWritableDatabase();
        String[] columns = {"text_question"};
        Cursor cursor = currentDB.query("Cards", columns, null ,null, null, null, null);
        cursor.moveToFirst();
        if(cursor != null && cursor.getCount() > 0){
            do{
                if (Objects.equals(cursor.getString(cursor.getColumnIndex("text_question")), myQuestion) && cursor.getColumnIndex("id_question") != currentId){
                    isPresent = true;
                }
            }while (cursor.moveToNext());    // Reading the all TABLE
        }
        return isPresent;
    }

////////////// DECK DATA FUNCTIONS ////////////////////////

    public int read_Data_Decks_Amount(){
        String SQL = "SELECT * FROM Decks";
        Cursor cursor = this.getReadableDatabase().rawQuery(SQL, null);
        cursor.moveToFirst();
        int iNumberOfDecks ;

        if(cursor != null && cursor.getCount() > 0){
            iNumberOfDecks = cursor.getCount();
        }
        else{
            iNumberOfDecks = 0;
        }

        if(cursor != null && cursor.moveToFirst()){
            // Partie sur la gestion des différentes informations lues par le Cursor!
            do{
                if (cursor.getColumnIndex("id_deck") >0){
                    @SuppressLint("Range") int id = cursor.getInt(cursor.getColumnIndex("id_deck"));
                    @SuppressLint("Range") String Deck_name = cursor.getString(cursor.getColumnIndex("deck_name"));
                    Log.d("ID_Decks", String.valueOf(id));
                    Log.d("ID_Decks", Deck_name);
                }
            } while(cursor.moveToNext());
        }

        //Log.d("NUMB DECKS", String.valueOf(iNumberOfDecks));
        return iNumberOfDecks+1;
    }

    public void insert_Data_Decks_Table(String strData){
        /*String SQL = "INSERT INTO Decks ( deck_name ) " +
                "VALUES ('" + strData + "') ";
        this.getWritableDatabase().execSQL(SQL); */

        SQLiteDatabase currentDB = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("deck_name", strData);

        currentDB.insert("Decks", null, values);
    }

    public String read_Data_Deck_Name(int currentID){
        // Reading only the Question from a specific ID
        String SQL = "SELECT * FROM Decks WHERE id_deck = " + currentID;
        Cursor cursor = this.getReadableDatabase().rawQuery(SQL, null);
        cursor.moveToFirst();

        if(cursor != null && cursor.getCount() > 0){
            String str = cursor.getString(1); // The Text
            return str ;
        }
        else {
            return null;
        }
    }

    public int[] read_Deck_IDs(int iAmount){
        int[] iValues = new int[iAmount];
        String SQL = "SELECT * FROM Decks WHERE id_deck != 0";
        Cursor cursor = this.getReadableDatabase().rawQuery(SQL, null);
        cursor.moveToFirst();

        for (int i=1; i<iAmount;i++){
            iValues[i] = cursor.getInt(0);
            //Log.d("DECK IDs Numb", String.valueOf(iAmount));
            //Log.d("DECK IDs Numb", String.valueOf(i) + " compte actuel");
            cursor.moveToNext();
        }
        return iValues;
    }

    @SuppressLint("Range")
    public String[] read_All_Decks_Name(){
        // Voir ici si la carte à un Deck
            // Si la carte à AU MOINS un Deck, alors il l'affiche ici (max. 3decks?)
        int iNbDecks = 0;
        //String[] strTempo = new String[0];
        ArrayList<String> strTempo = new ArrayList<>();

        String SQL = "SELECT * FROM Decks";
        Cursor cursor = this.getReadableDatabase().rawQuery(SQL, null);
        cursor.moveToFirst();

        if(cursor != null && cursor.getCount() > 0){
            do {
                // Ajouter les noms des DECKS dans le tableau strResult[]
                Log.d("MY TAG CURSOR",cursor.getString(cursor.getColumnIndex("deck_name")));
                strTempo.add(cursor.getString(cursor.getColumnIndex("deck_name")));
                Log.d("NB ELEMENTS DECKS", "Nb = "+ iNbDecks);
                iNbDecks++;
            } while(cursor.moveToNext());
        }
        else {
            Log.d("NB ELEMENTS DECKS", "Rien du tout!");
        }

        return strTempo.toArray(new String[iNbDecks]);
    }

    public void save_deck_on_card(int id_card, String strDeckName){
        // Function to save the name of the Deck for the Card
        // Il faut insérer ce deck dans la case de la base de donnée dédiée à cette carte précisé
            // J'ai besoin de son identifiant!
        /*String SQL = "UPDATE Cards SET meta_deck= '"+ strDeckName + "' WHERE id_card = " + id_card;
        this.getWritableDatabase().execSQL(SQL); */


        SQLiteDatabase currentDB = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("meta_deck", strDeckName);
        String selection = "id_card = ?";
        String[] selectionArgs = { String.valueOf(id_card) };

        currentDB.update("Cards", values, selection, selectionArgs);
    }

    @SuppressLint("Range")
    public String retrieve_Deck_Name(int id_card){
        String strMyDeckName = "none";
        String SQL = "SELECT meta_deck FROM Cards WHERE id_card = " + id_card;
        Cursor cursor = this.getReadableDatabase().rawQuery(SQL, null);
        Log.d("INFO TEMP", "PARTIE 1");
        cursor.moveToFirst();
        Log.d("INFO TEMP", "PARTIE 2");
        if (cursor.getString(cursor.getColumnIndex("meta_deck")) != null){
            strMyDeckName = cursor.getString(cursor.getColumnIndex("meta_deck"));
        } else {
            strMyDeckName = "No deck YET";
        }

        Log.d("INFO TEMP", strMyDeckName);
        return strMyDeckName;
    }





    /////////////////////// CATEGORIES Data functions /////////////////
    public int read_Data_Categories_Amount(){
        String SQL = "SELECT * FROM Categories";
        Cursor cursor = this.getReadableDatabase().rawQuery(SQL, null);
        cursor.moveToFirst();
        int iNumberOfCat = 0;

        if(cursor != null && cursor.getCount() > 0){
            iNumberOfCat = cursor.getCount();
        }
        else{
            iNumberOfCat = 0;
        }

        if (cursor!=null && cursor.moveToFirst()){
            do{
                @SuppressLint("Range") int id = cursor.getInt(cursor.getColumnIndex("id_cat"));
                @SuppressLint("Range") String Cat_name = cursor.getString(cursor.getColumnIndex("cat_name"));
                Log.d("ID_Name", String.valueOf(id));
                Log.d("ID_Name", Cat_name);
            } while (cursor.moveToNext());
        }

        //Log.d("NUMB DECKS", String.valueOf(iNumberOfDecks));
        return iNumberOfCat+1;
    }

    public void insert_Data_Categories_Table(String strData){
        /*String SQL = "INSERT INTO Categories ( cat_name ) " +
                "VALUES ('" + strData + "') ";
        this.getWritableDatabase().execSQL(SQL); */

        SQLiteDatabase currentDB = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("cat_name", strData);

        currentDB.insert("Categories", null, values);
    }

    public String read_Data_Category_Name(int currentID){
        // Reading only the Question from a specific ID
        String SQL = "SELECT * FROM Categories WHERE id_cat = " + currentID;
        Cursor cursor = this.getReadableDatabase().rawQuery(SQL, null);
        cursor.moveToFirst();

        if(cursor != null && cursor.getCount() > 0){
            String str = cursor.getString(1); // The Text
            return str ;
        }
        else {
            return null;
        }
    }

    public int[] read_Category_IDs(int iAmount){
        int[] iValues = new int[iAmount];
        String SQL = "SELECT * FROM Categories WHERE id_cat != 0";
        Cursor cursor = this.getReadableDatabase().rawQuery(SQL, null);
        cursor.moveToFirst();

        for (int i=1; i<iAmount;i++){
            iValues[i] = cursor.getInt(0);
            cursor.moveToNext();
            Log.d("DECK IDs Numb", String.valueOf(iAmount));
            Log.d("DECK IDs Numb", String.valueOf(i) + " compte actuel");
        }
        return iValues;
    }

}

