package com.example.memoboost_v2;


import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


//

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder>{
    Context myContext;
    public CardDatabaseDataList[] listData;
    private Intent intent;

    public MyAdapter(Context myContext, CardDatabaseDataList[] listData, Intent intent) {
        this.myContext = myContext;
        this.listData = listData;
        this.intent = intent;
    }

    @NonNull
    @Override
    public MyAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(myContext).inflate(R.layout.single_item_view, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapter.ViewHolder holder, int position) {
        holder.myDbElement.setText(listData[position].getName());
        Log.d("NUMB CARDS", String.valueOf(position));
        holder.myImage.setImageResource(listData[position].getImgId());
        int i = position;
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // I get The clicked Item's ID and I now have to open the new Activity "CreateCardScreen" from here
                    //Toast.makeText(view.getContext(), "Item clicked: " + listData[i].getiIDCard(), Toast.LENGTH_SHORT).show();
                // Open the CreateCardScreen.Java class!
                intent.putExtra("ID_Card", listData[i].getiIDCard());
                intent.putExtra("Card_Type", "Update");
                myContext.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return listData.length;
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView myDbElement;
        ImageView myImage;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            myDbElement = (TextView) itemView.findViewById(R.id.txtViewDbElement);
            myImage = (ImageView) itemView.findViewById(R.id.imageView);
        }
    }




}

